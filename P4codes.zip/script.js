const q = (sel, ctx=document) => ctx.querySelector(sel);
const qq = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));
const formatCurrency = n => Number(n).toFixed(2);

function connectMenuControls(menuId, overlayId, menuBtnId, closeBtnId) {
  const side = document.getElementById(menuId);
  const overlay = document.getElementById(overlayId);
  const openBtn = document.getElementById(menuBtnId);
  const closeBtn = document.getElementById(closeBtnId);

  if (!side) return;

  const openMenu = () => { side.classList.add('open'); overlay.classList.add('show'); side.setAttribute('aria-hidden','false'); };
  const closeMenu = () => { side.classList.remove('open'); overlay.classList.remove('show'); side.setAttribute('aria-hidden','true'); };

  if (openBtn) openBtn.addEventListener('click',openMenu);
  if (closeBtn) closeBtn.addEventListener('click',closeMenu);
  if (overlay) overlay.addEventListener('click', ()=> { closeMenu(); closeCartPanels(); });
}

connectMenuControls('sideMenu','overlay','menuBtn','closeMenuBtn');
connectMenuControls('sideMenuAbout','overlayAbout','menuBtnAbout','closeMenuBtnAbout');
connectMenuControls('sideMenuContact','overlayContact','menuBtnContact','closeMenuBtnContact');

function attachThemeButtons(btnIds){
  btnIds.forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    btn.addEventListener('click', () => {
      document.body.classList.toggle('dark');
      // persist
      localStorage.setItem('stanley_theme_dark', document.body.classList.contains('dark'));
    });
  });

  if (localStorage.getItem('stanley_theme_dark') === 'true') {
    document.body.classList.add('dark');
  }
}
attachThemeButtons(['themeBtn','themeBtnAbout','themeBtnContact']);

let CART_KEY = 'stanley_cart_v1';
let cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]');

function saveCart(){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartUI(); }

function addToCartItem(item){
  cart.push(item);
  saveCart();
  animateAddToCart(item);
}

document.addEventListener('click', (e) => {
  const add = e.target.closest('.add-btn');
  if (!add) return;
  const card = add.closest('.product-card');
  if (!card) return;
  const name = card.dataset.name || q('.product-title', card).innerText;
  const price = Number(card.dataset.price || 0);
  const img = card.dataset.image || q('img', card).src;
  addToCartItem({ name, price, img });
});

function updateCartUI() {
  const panel = q('#cartPanel');
  const list = q('#cartItems');
  const totalEl = q('#cartTotal');
  const count = cart.length;

  if (list) {
    list.innerHTML = '';
    cart.forEach((it, i) => {
      const li = document.createElement('li');
      const img = document.createElement('img'); img.src = it.img; img.alt = it.name;
      const info = document.createElement('div'); info.className = 'cart-item-info';
      const title = document.createElement('strong'); title.textContent = it.name;
      const small = document.createElement('small'); small.textContent = `$${formatCurrency(it.price)}`;
      info.appendChild(title); info.appendChild(small);
      const del = document.createElement('button'); del.className = 'btn-outline'; del.textContent = 'Remove';
      del.addEventListener('click', () => {
        cart.splice(i,1);
        saveCart();
      });
      li.appendChild(img); li.appendChild(info); li.appendChild(del);
      list.appendChild(li);
    });
  }

  const listAbout = q('#cartItemsAbout');
  if (listAbout) {
    listAbout.innerHTML = '';
    cart.forEach((it,i)=> {
      const li = document.createElement('li');
      li.textContent = `${it.name} — $${formatCurrency(it.price)}`;
      listAbout.appendChild(li);
    });
    q('#cartTotalAbout').textContent = formatCurrency(cart.reduce((s,i)=>s+i.price,0));
  }

  const listContact = q('#cartItemsContact');
  if (listContact) {
    listContact.innerHTML = '';
    cart.forEach((it,i)=> {
      const li = document.createElement('li');
      li.textContent = `${it.name} — $${formatCurrency(it.price)}`;
      listContact.appendChild(li);
    });
    q('#cartTotalContact').textContent = formatCurrency(cart.reduce((s,i)=>s+i.price,0));
  }

  if (q('#cartCount')) q('#cartCount').textContent = count;
  if (q('#cartCountAbout')) q('#cartCountAbout').textContent = count;
  if (q('#cartCountContact')) q('#cartCountContact').textContent = count;
  if (totalEl) totalEl.textContent = formatCurrency(cart.reduce((s,i)=>s+i.price,0));
  if (q('#cartTotal')) q('#cartTotal').textContent = formatCurrency(cart.reduce((s,i)=>s+i.price,0));
}

saveCart();

function toggleCartPanel(panelId = 'cartPanel') {
  const panel = document.getElementById(panelId);
  if (!panel) return;
  const open = panel.classList.toggle('open');
  const overlay = q('#overlay'); if (overlay) overlay.classList.toggle('show', open);
  panel.setAttribute('aria-hidden', !open);
}
function closeCartPanels(){
  qq('.cart-panel').forEach(p=>p.classList.remove('open'));
  const o = q('#overlay'); if (o) o.classList.remove('show');
}

const cartBtn = q('#cartBtn'); if (cartBtn) cartBtn.addEventListener('click', ()=> toggleCartPanel('cartPanel'));
const cartBtnAbout = q('#cartBtnAbout'); if (cartBtnAbout) cartBtnAbout.addEventListener('click', ()=> toggleCartPanel('cartPanelAbout'));
const cartBtnContact = q('#cartBtnContact'); if (cartBtnContact) cartBtnContact.addEventListener('click', ()=> toggleCartPanel('cartPanelContact'));
const closeCartBtn = q('#closeCartBtn'); if (closeCartBtn) closeCartBtn.addEventListener('click', ()=> toggleCartPanel('cartPanel'));
const closeCartBtnAbout = q('#closeCartBtnAbout'); if (closeCartBtnAbout) closeCartBtnAbout.addEventListener('click', ()=> toggleCartPanel('cartPanelAbout'));
const closeCartBtnContact = q('#closeCartBtnContact'); if (closeCartBtnContact) closeCartBtnContact.addEventListener('click', ()=> toggleCartPanel('cartPanelContact'));

const checkout = q('#checkoutBtn'); if (checkout) checkout.addEventListener('click', ()=> { alert('Checkout demo — implement real checkout passthrough.'); });
const checkoutA = q('#checkoutBtnAbout'); if (checkoutA) checkoutA.addEventListener('click', ()=> { alert('Checkout demo — implement real checkout passthrough.'); });
const checkoutC = q('#checkoutBtnContact'); if (checkoutC) checkoutC.addEventListener('click', ()=> { alert('Checkout demo — implement real checkout passthrough.'); });

function animateAddToCart(item) {
  const img = document.createElement('img');
  img.src = item.img;
  img.style.position = 'fixed';
  img.style.width = '120px';
  img.style.height = '120px';
  img.style.objectFit = 'cover';
  img.style.borderRadius = '10px';
  img.style.zIndex = 9999;
  img.style.transition = 'transform .8s cubic-bezier(.2,.9,.2,1), opacity .8s';
  document.body.appendChild(img);

  const source = document.querySelector(`img[src="${item.img}"]`) || document.querySelector('.product-media img');
  const cartIcon = document.querySelector('#cartBtn') || document.querySelector('.icon-btn[aria-label="Open cart"]');

  const srcRect = source.getBoundingClientRect();
  img.style.left = (srcRect.left + window.scrollX) + 'px';
  img.style.top = (srcRect.top + window.scrollY) + 'px';

  const targetRect = cartIcon.getBoundingClientRect();
  const targetX = (targetRect.left + targetRect.width/2) + window.scrollX - 40;
  const targetY = (targetRect.top + targetRect.height/2) + window.scrollY - 40;

  requestAnimationFrame(()=> {
    img.style.transform = `translate(${targetX - srcRect.left}px, ${targetY - srcRect.top}px) scale(.18) rotate(20deg)`;
    img.style.opacity = '0.2';
  });

  setTimeout(()=> {
    img.remove();
    const cartPanel = document.getElementById('cartPanel');
    if (cartPanel) {
      cartPanel.classList.add('open');
      const overlay = q('#overlay'); if (overlay) overlay.classList.add('show');
      setTimeout(()=> {  cartPanel.classList.remove('open'); if (overlay) overlay.classList.remove('show'); }, 1400);
    }
    updateCartUI();
  }, 900);
}


const contactForm = q('#contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Message sent (demo). Thank you!');
    contactForm.reset();
  });
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    qq('.side-menu.open').forEach(m=>m.classList.remove('open'));
    qq('.cart-panel.open').forEach(p=>p.classList.remove('open'));
    qq('.overlay.show').forEach(o=>o.classList.remove('show'));
  }
});

document.addEventListener('DOMContentLoaded', () => {
  updateCartUI();
});
